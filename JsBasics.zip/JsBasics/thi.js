const human = { 
 name:"Rama",
 eat() {
      console.log(this);
    }
};

human.eat();

const eat=human.eat.bind(human);
eat();