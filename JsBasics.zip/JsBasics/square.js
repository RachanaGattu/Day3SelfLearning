const square = number => number * number;
console.log(square(9));